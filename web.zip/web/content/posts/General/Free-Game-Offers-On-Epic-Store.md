---
title: "Free Game Offers On Epic Store"
date: 2022-01-07T13:00:00Z
draft: false
categories: ["General","Gaming"]
tags: ["windows","how-to","gaming"]
author: "Kavishka Dahanayaka"
showToc: true
TocOpen: false
hidemeta: false
comments: true
description: "Desc Text."
canonicalURL: "https://canonical.url/to/page"
disableHLJS: true # to disable highlightjs
disableShare: false
hideSummary: false
searchHidden: false
ShowReadingTime: true
ShowBreadCrumbs: true
ShowPostNavLinks: true
ShowWordCount: true
ShowCodeCopyButtons: true
ShowRssButtonInSectionTermList: true
UseHugoToc: true
cover:
    image: "" # image path/url
    alt: "<alt text>" # alt text
    caption: "<text>" # display caption under cover
    relative: false # when using page bundles set this to true
    hidden: true # only hide on current single page
editPost:
    URL: "https://github.com/xkavishka/blog/edit/main/content/default.md"
    Text: "Suggest Changes" # edit text
    appendFilePath: true # to append file path to Edit link
---